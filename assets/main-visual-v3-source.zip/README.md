# Automotive-ENV luxury main visual

The composition uses an AI-generated concept cockpit setting, four original AAOS capture streams, and separately editable typography, frames and connectors. It illustrates a requested task and the post-episode evaluation protocol; no example result is asserted. The underlying setting is 1672 × 941 pixels. The authored composition and main PNG are 2400 × 1350 pixels.

- `main.png` and `main.webp`: webpage assets.
- `main.svg` and `main.html`: self-contained mixed-media composition with native text and geometry plus embedded raster layers and embedded OFL fonts.
- `main.pptx`: layered editable presentation. The setting and AAOS screenshots are individual picture objects; labels, frames and connectors are native objects. The main AAOS picture uses an explicit crop of the original stream.
- `main.pdf`: actual LibreOffice rendering of the layered PPTX; it is a mixed raster/vector PDF.
- `main-ppt-render.png` and `main-ppt-web1200.png`: actual PDF render previews. `main-web1200.png` is the browser preview at typical webpage width.
- `source/`: exact original image layers, font variables and static weights, OFL licenses, provenance, and reproduction scripts. Fonts are supplied as dependencies rather than claiming that PPTX embeds them.
- `main-scene.json`, `main-font-proof.json`, `native-font-match.json`, `technical-audit.json` and `manifest.json`: geometry, source hashes and actual renderer evidence.

This is deliberately mixed media. Photography and source screenshot pixels are raster, while labels and annotation geometry remain editable. It is not a pure-vector illustration.

For exact PPT editing, install the provided `Manrope-600.ttf` and `SpaceGrotesk-450.ttf` from `source/fonts/` in your editing environment. Their family aliases are `Manrope Figure 600` and `SpaceGrotesk Figure 450`. The provided rendering script instead uses a project-scoped fontconfig file, so it does not install global fonts.

Reproduce in Python with Pillow, fontTools, python-pptx, lxml, PyMuPDF and Playwright, plus Chromium and LibreOffice. Set `CHROME_BINARY` and `FIGURE_SCRATCH` as appropriate, then run `python source/build_composites.py --candidate a --name main --pptx --output .`. The native rendering helper documents the scoped-font LibreOffice path used for this delivery.
